All notable changes to this project will be documented in this file.

##  [03.05.00.1574] 2023-01-23
### Added
-    "New GNA 3.0 HWIDs"

##  [03.05.00.1472] 2022-01-20
### Added
-    "New GNA 3.5 HWIDs"

##  [03.05.00.1434] 2021-09-15
### Fixed
-    "HSD16014575636 The Unit run WHQL test occur BSOD(0xE6)"
-    "CA issues"
-    "inf2cat timestamp issue"
-    "SDV invalid request issue"
### Changed
-    "Updated project for latest WDK"
-    "Moved legacy API to Driver.h"
### Added
-    "IRQL tracing and KeRaiseIrql for additional protection"

##  [03.05.00.1285] 2021-06-11
### Changed
-    "Updated version to 3.5"

## [02.01.00.1278] 2021-06-10
### Removed
-    "Unnecessary 2.0 QoS feature"

## [02.01.00.1263] 2021-06-02
### Fixed
-    "HSD22013185173 incorrect HWID on platform SoC"

## [02.01.00.1257] 2021-05-31
### Fixed
-    "Non-HW related parameters rejected by invalid condition"

## [02.01.00.1242] 2021-05-14
### Added
-    "3.0 QoS feature"

## [02.01.00.1231] 2021-05-05
### Fixed
-    "Minor security issues"

## [02.01.00.1231] 2021-04-19
### Added
-    "File Digest Algorithm to enable EWDK test-signing"

## [02.01.00.1207] 2021-03-23
### Fixed
-    "Added missing HWID for GNA 3.0 in inf"

## [02.01.00.1160] 2021-03-15
### Added
-    "Another HWID for GNA 3.0"

## [02.01.00.1055] 2020-10-22
### Changed
-    "Refactored memory mapping mechanism"

## [02.01.00.1055] 2020-08-28
### Fixed
-    "Secure memory map/unmap flow for invalid request object in map cncl evnt"

## [02.01.00.1048] 2020-07-28
### Fixed
-    "Fixed missing security permissions 2"

## [02.01.00.1045] 2020-07-23
### Removed
-    "Legacy interrupt support, simplified project"

## [02.01.00.1035] 2020-07-22
### Fixed
-    "Fixed missing security permissions"

## [02.01.00.1032] 2020-07-21
### Changed
-    "Merged Release 2.0 changes"

## [02.01.00.0982] - 2020-07-01
### Changed
-    "Update GNA 3.5 HWID"
-    "Code cleanup for release and protex issues"

### Fixed
-    "WDK 20H1 warning fixes"

## 2020-06-26
### Fixed
-    "WDK 20H1 warning fixes"
-    "Security Review - Code review fixes"

## [02.00.00.0925] - 2020-05-26
### Added
-    "Model error reporting"
-    "DDI: Notify removal"
-    "20h1 WDK support"

### Fixed
-    "Performance instrumentation fix"

### BKMs/Notes

1.  Hardware Compatibility

    The GNA CPU offload and acceleration capability is supported by the following Intel platforms in the post-Si:
    *    Gemini Lake
    *    Cannon Lake
    *    Elkhart Lake
    *    Ice Lake
    *    Jasper Lake+
    *    Rocket Lake
    *    Tiger Lake
    *    Alder Lake

2.  Supported Operating Systems

    The GNA SW stack supports in general the OSes:
    *    Microsoft* Windows*

    Details of the support for Microsoft* OSes:
    *    Windows* 10 Threshold 1
    *    Windows* 10 Threshold 2
    *    Windows* 10 Red Stone 1
    *    Windows* 10 Red Stone 2
    *    Windows* 10 Red Stone 3
    *    Windows* 10 Red Stone 4
    *    Windows* 10 Red Stone 5
    *    Windows* 10 Red Stone 6
    *    Windows* 10 2019H1
    *    Windows* 10 2019H2
    *    Windows* 10 2020H1